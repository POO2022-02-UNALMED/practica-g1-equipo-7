from enum import Enum

class CATEGORIA(Enum):
    ACTUALIDAD = "Actualidad"
    ENTRETENIMIENTO = "Entretenimiento"
    POLITICA = "Politica"