from enum import Enum

class GENERO(Enum):
    NOVELA = "Novela"
    CIENCIA = "Ciencia"
    HISTORICA = "Historica"
    FILOSOFIA = "Filosofia"
    ROMANTICISMO = "Romaticismo"
    FANTASIA = "Fantasia"
    CUENTO = "Cuento"

